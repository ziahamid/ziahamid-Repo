package com.example.swagger.api.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.swagger.api.dao.BookRepository;
import com.example.swagger.api.model.Book;

@Service
public class BookService 
{
	@Autowired
	private BookRepository bookRepository;
	
	private static final Logger LOG = LoggerFactory.getLogger("BookService");
	
	public String saveBook(Book book)
	{
		LOG.info("BookService - saveBook()");
		bookRepository.save(book);
		return "Book saved successfully with Id " + book.getBookId() ;
	}
	
	public Book getBook(int bookId)
	{
		LOG.info("BookService - getBook()");
		//return bookRepository.findOne(bookId);
	  return null;
	}
	
	public List<Book> removeBook(int bookId)
	{
		LOG.info("BookService - removeBook()");
		bookRepository.deleteById(bookId);
		return bookRepository.findAll();
	}

}
