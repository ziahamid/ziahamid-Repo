package com.example.swagger.api.config;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class BookConfig 
{	
	public Docket postApi()
	{
		return new Docket(DocumentationType.SWAGGER_2).groupName("TCI").apiInfo(apiInfo()).select().paths(regex("/book.*")).build();
	}

	public ApiInfo apiInfo()
	{
		return new ApiInfoBuilder().title("BookService")
				.description("Sample Document generated from SWAGGER2 for our Book Rest API")
		        .termsOfServiceUrl("https://www.youtube.com/watch?v=2bt11jYIp6E&t=0s&list=PLVz2XdJiJQxw-jVLpBfVn2yqjvA1Ycceq&index=12")
		        .license("Java - Techie License").version("1.0").build();
	}
}
